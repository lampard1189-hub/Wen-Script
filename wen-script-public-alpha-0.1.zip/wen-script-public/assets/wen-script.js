/* Wen Script 0.1 — reversible English substitution alphabet.
   This is a writing system experiment, not encryption. */
(() => {
  "use strict";
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const glyphs = ["⟊","⟒","⊂","◖","Ξ","⨍","⊙","⟟","⟐","⌁","⟑","⌞","⋔","⋏","◯","⊓","⊚","⟡","ϟ","⊤","∪","⋎","⌘","⨯","⟠","⌬"];
  const digits = ["○","◔","◑","◕","●","◖","◗","◘","◙","◎"];
  const punctuation = new Map([
    [" ","　"],[".","·"],[",","‚"],["?","¿"],["!","¡"],["'","’"],['"',"”"],
    [":","∶"],[";","؛"],["-","−"],["_","＿"],["(","⟮"],[")","⟯"],["/","／"],
    ["&","⅋"],["@","＠"],["#","♯"],["+","＋"],["=","＝"]
  ]);
  const reverse = new Map(glyphs.map((g,i)=>[g,alphabet[i]]));
  digits.forEach((g,i)=>reverse.set(g,String(i)));
  for (const [a,b] of punctuation) reverse.set(b,a);

  const english = document.getElementById("english");
  const output = document.getElementById("wenOutput");
  const binary = document.getElementById("binaryToggle");
  const status = document.getElementById("status");
  const charCount = document.getElementById("charCount");
  const outputCount = document.getElementById("outputCount");

  function encode(text) {
    return Array.from(text).map(ch => {
      const upper = ch.toUpperCase();
      if (alphabet.includes(upper)) {
        const i = alphabet.indexOf(upper);
        const symbol = glyphs[i];
        return binary.checked ? symbol + "₍" + i.toString(2).padStart(5,"0") + "₎" : symbol;
      }
      if (/^[0-9]$/.test(ch)) return digits[Number(ch)];
      return punctuation.get(ch) ?? ch;
    }).join("");
  }
  function decode(text) {
    // Remove optional binary annotations, then decode symbols.
    const cleaned = text.replace(/₍[01]{5}₎/g,"");
    return Array.from(cleaned).map(ch => reverse.get(ch) ?? ch).join("");
  }
  function updateCounts() {
    charCount.textContent = `${Array.from(english.value).length} characters`;
    outputCount.textContent = `${Array.from(output.value).length} symbols`;
  }
  function runEncode() {
    output.value = encode(english.value);
    status.textContent = "Encoded";
    updateCounts();
  }
  function runDecode() {
    const decoded = decode(output.value);
    english.value = decoded;
    status.textContent = "Decoded";
    updateCounts();
  }
  document.getElementById("encodeBtn").addEventListener("click",runEncode);
  document.getElementById("decodeBtn").addEventListener("click",runDecode);
  document.getElementById("clearBtn").addEventListener("click",() => {
    english.value = ""; output.value = ""; status.textContent = "Cleared"; updateCounts(); english.focus();
  });
  document.getElementById("copyBtn").addEventListener("click",async () => {
    try { await navigator.clipboard.writeText(output.value); status.textContent = "Copied"; }
    catch { output.select(); status.textContent = "Select and copy"; }
  });
  english.addEventListener("input",updateCounts);
  output.addEventListener("input",updateCounts);
  binary.addEventListener("change",() => { if (english.value) runEncode(); });
  const grid = document.getElementById("alphabetGrid");
  alphabet.split("").forEach((letter,i) => {
    const item = document.createElement("div");
    item.className = "letter";
    item.innerHTML = `<span class="latin">${letter}</span><span class="glyph">${glyphs[i]}</span><span class="bits">${i.toString(2).padStart(5,"0")}</span>`;
    grid.appendChild(item);
  });
  runEncode();
})();